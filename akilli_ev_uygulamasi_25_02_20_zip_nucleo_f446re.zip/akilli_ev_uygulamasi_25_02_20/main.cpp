#include "mbed.h"
#include "rtos.h"
#include "TextLCD.h"
#include "DHT11.h"
#define lamba a
#define motoracik m //180
#define motorkapali x//0
DHT11 sicaklik(PB_13);
float ldr_oku;
AnalogIn ldr(PA_0);
DigitalOut bzr(PB_7);
DigitalOut role(PA_8);//Lamba için kullanıldı
DigitalOut servo(PB_10);
Serial bt(PC_10,PC_11);
TextLCD lcd(PB_0, PA_4,PC_3, PC_2, PB_3, PA_10); // rs, e, d4-d7
Thread lcdcalisma;

void lcd_metodu()
{
while(1)
{ 
for(uint8_t digit=0;digit<=9;digit++)//Yazı sağa doğru kayar
{
lcd.locate(13,1);//2 satır 14. digit
lcd.printf("%.1f",ldr_oku);

lcd.locate(10,1);
lcd.printf("%d", sicaklik.readTemperature());
lcd.locate(digit,0); 
lcd.printf(" mehmet");
wait_ms(400);
}
for(uint8_t digit=9;digit>0;digit--)//yazı sola doğru kayar
{
lcd.locate(13,1);//2 satır 14. digit
lcd.printf("%.1f",ldr_oku);
lcd.locate(10,1);
lcd.printf("%d", sicaklik.readTemperature());
lcd.locate(digit,0); 
lcd.printf("mehmet ");
wait_ms(400);
}
}
}

int main()
{
lcdcalisma.start(lcd_metodu);
bt.baud(38400);
char gelen[0];
bool durum1=false,durum2=false;
while(true) {
sicaklik.readData();
ldr_oku=ldr.read();//0.0 ile 1.0 arasında okuma yapar.

if(ldr_oku>0.6f && durum1==false)
{
durum1=true;
durum2=false;
lcd.cls();
lcd.locate(0,1);
role=1;
lcd.printf("L. On");
}
else if(ldr_oku<0.6f && durum2==false)
{
durum2=true;
durum1=false;
lcd.cls();
lcd.locate(0,1);
role=0;
lcd.printf("L. Off");
}

if(bt.readable())
{
gelen[0]=bt.getc();
if(gelen[0]=='L')
{
lcd.cls();
lcd.locate(0,1);
role=!role;
if(role==1)
lcd.printf("L. On");
if(role==0)
lcd.printf("L. OFF");
bzr=1;wait_ms(50);bzr=0;
}
else if(gelen[0]=='a')
{
lcd.cls();
lcd.locate(0,1);
lcd.printf("K.Acik");
bzr=1;wait_ms(50);bzr=0;
for(char tekrar=0;tekrar<30;tekrar++)
{
servo=1;
wait_us(2400);
servo=0;
wait_us(17600);
}

}
else if(gelen[0]=='k')
{
lcd.cls();
lcd.locate(0,1);
lcd.printf("K.kapali");
bzr=1;wait_ms(50);bzr=0;
for(char tekrar=0;tekrar<30;tekrar++)
{
servo=1;
wait_us(600);
servo=0;
wait_us(19400);
}

}
}

}
}