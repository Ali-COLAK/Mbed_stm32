#include "mbed.h"
#include "rtos.h"
#define hiz 10
int deger=0,deger_servo=600;
bool kontrol=false;
Thread gorev1,gorev2,gorev3;//iş parçacıkları oluşturuldu.
BusOut faz(PC_0,PC_1,PB_0,PA_4);
DigitalOut servo(PB_10);
DigitalOut ses(PB_7);
void buzzer_metodu()
{
while(1)
{
ses=!ses;
wait(2);
}
}
void gorev1_metodu()
{
while(1)
{
deger++;
if(deger<500)
{
faz[0]=1;
faz[1]=0;
faz[2]=0;
faz[3]=0;
wait_ms(3);
faz[0]=0;
faz[1]=1;
faz[2]=0;
faz[3]=0;
wait_ms(3);
faz[0]=0;
faz[1]=0;
faz[2]=1;
faz[3]=0;
wait_ms(3);
faz[0]=0;
faz[1]=0;
faz[2]=0;
faz[3]=1;
wait_ms(3);
}
else if(deger<1000)
{
faz[0]=0;
faz[1]=0;
faz[2]=0;
faz[3]=1;
wait_ms(3);
faz[0]=0;
faz[1]=0;
faz[2]=1;
faz[3]=0;
wait_ms(3);
faz[0]=0;
faz[1]=1;
faz[2]=0;
faz[3]=0;
wait_ms(3);
faz[0]=1;
faz[1]=0;
faz[2]=0;
faz[3]=0;
wait_ms(3);
}
else
{
deger=0;
}
}
}
void gorev2_metodu()
{
while(1)
{
if(deger_servo<=2400 && kontrol==false)
deger_servo+=hiz;
else if(deger_servo>2400)
kontrol=true;

if(deger_servo>=600 && kontrol==true)
deger_servo-=hiz;
else if(deger_servo<600)
kontrol=false;

servo=1;
wait_us(deger_servo);
servo=0;
wait_us(20000-deger_servo);
}
}
int main()
{
gorev3.start(buzzer_metodu);
gorev1.start(gorev1_metodu);//gorev1 iş parçacığı gorev1_metodu ile bağlandı
gorev2.start(gorev2_metodu);//gorev2 iş parçacığı gorev2_metodu ile bağlandı
while(1) {
printf("Merhaba\n");wait(0.5);
}
return 0;
}