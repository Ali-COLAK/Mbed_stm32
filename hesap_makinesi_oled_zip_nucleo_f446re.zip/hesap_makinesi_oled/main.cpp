#include "mbed.h"

#include "Keypad.h"
#include "ssd1306.h"
#include <iostream>

SSD1306 lcd (I2C_SDA, I2C_SCL);
DigitalOut bzr(PB_7);
Serial pc(USBTX,USBRX);

float sayi[4]= {0,0,0,0};
/*
sayi[0] girilen sayi
sayi[1] 1. sayi
sayi[2] 2sayi
sayi[3] sonuc
*/
char basilantus,islem;

Keypad key(PC_4, PB_13, PB_14,PB_15,PB_1,PB_2,PB_12,PA_11);
char key_table[] = {
    '1', '2', '3', '+',
    '4', '5', '6', '-',
    '7', '8', '9', '*',
    'C', '0', '=', '/'
};


int main()
{
    pc.baud(115200);
    // Init. RC522 Chip
    uint32_t key_num;
    
    lcd.speed (SSD1306::Medium);  // set working frequency
            lcd.init();                   // initialize SSD1306
            lcd.cls();                    // clear frame buffer
    
    while(true) {

        while ((key_num = key.read()) != 0) {
            bzr=1;
            wait_ms(10);
            bzr=0;
            basilantus=*(key_table + key_num-1);

            
            lcd.locate (3,1);             // set text cursor to line 3, column 1
            lcd.printf ("%c",basilantus); // print to frame buffer


            lcd.redraw();                 // updates actual display transferring frame buffer over I2C bus


            lcd.set_contrast (150);            // set contrast
            wait_ms (20);                           // waits a little to prevent excesive I2C traffic









            switch(basilantus) {
                case '0'...'9'://if(basilantus>'0' && basilantus<'9')
                    sayi[0]=sayi[0]*10+(basilantus-'0');
                    break;
                case '*'...'/':
                    /*case '-':
                    case '+':
                    case '*':
                    case '/':*/
                    islem=basilantus;
                    sayi[1]=sayi[0];
                    sayi[0]=0;
                    break;
                case '=':
                    sayi[2]=sayi[0];
                    if(islem=='+')
                        sayi[3]=sayi[1]+sayi[2];
                    else if(islem=='-')
                        sayi[3]=sayi[1]-sayi[2];
                    else if(islem=='*')
                        sayi[3]=sayi[1]*sayi[2];
                    else if(islem=='/')
                        sayi[3]=sayi[1]/sayi[2];

                    lcd.printf("%.2f",sayi[3]);
                    for(char temizle=0; temizle<=3; temizle++) {
                        sayi[temizle]=0;
                    }
                    islem=0;
                    break;

                case 'C':
                    lcd.cls();
                    for(char temizle=0; temizle<=3; temizle++) {
                        sayi[temizle]=0;
                    }
                    islem=0;
                    break;
            }

        }//   while ((key_num = key.read()) != 0) {

    }//  while(true) {

}//main




lcd.speed (SSD1306::Medium);  // set working frequency
lcd.init();                   // initialize SSD1306
lcd.cls();                    // clear frame buffer
lcd.locate (3,1);             // set text cursor to line 3, column 1
lcd.printf ("Hello, world!"); // print to frame buffer


lcd.redraw();                 // updates actual display transferring frame buffer over I2C bus


lcd.set_contrast (150);            // set contrast
wait_ms (20);                           // waits a little to prevent excesive I2C traffic
